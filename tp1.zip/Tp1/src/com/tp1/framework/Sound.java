package com.tp1.framework;

public interface Sound {
	public void play(float volume);

    public void dispose();
}
