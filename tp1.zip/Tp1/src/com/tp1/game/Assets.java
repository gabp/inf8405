package com.tp1.game;

import com.tp1.framework.Image;
import com.tp1.framework.Sound;

public class Assets {    
    public static Image homer;
    public static Image bart;
    public static Image duff;
    public static Image maggie;
    public static Image donut;
    public static Image marge;
    public static Image grandpa;
    public static Image win;
    
    
    public static Sound click;
}